PROPOSAL WEBSITE STARTER
- Open index.html in a browser or upload it to your website host.
- Add photos/music later in the assets folder, then update the matching placeholders in index.html.
- The music button is included; browsers usually require a tap before music can play.
- Current page uses no external libraries.
